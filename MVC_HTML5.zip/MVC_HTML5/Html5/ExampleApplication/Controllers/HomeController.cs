﻿using System.Web.Mvc;
using ExampleApplication.Models;
using System;

namespace ExampleApplication.Controllers
{
    public class HomeController : Controller
    {
        #region Index
        public ActionResult Index()
        {
            Customer customer = new Customer {CreatedDate = DateTime.Now, IsActive = true, CustomerAge = 30};

            return View(customer);
        }

        [HttpPost]
        public ActionResult Index(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return View(customer);
            }

            return View(customer);
        }

        #endregion

        #region About
        
        public ActionResult About()
        {
            return View();
        }

        #endregion
    }
}
