﻿using System.ComponentModel.DataAnnotations;

namespace Example.Models
{
    public class Customer
    {
        [Required]
        public string CustomerName { get; set; }

        public string CustomerEmail { get; set; }
    }
}
