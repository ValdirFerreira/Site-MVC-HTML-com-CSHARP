﻿namespace Example.Models
{
    public class Company
    {
        public string CompanyName { get; set; }
    }
}