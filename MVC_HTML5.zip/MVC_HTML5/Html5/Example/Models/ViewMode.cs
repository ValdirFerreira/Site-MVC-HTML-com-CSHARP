﻿namespace Example.Models
{
    public class ViewMode
    {
        public Company Company { get; set; }
    }
}