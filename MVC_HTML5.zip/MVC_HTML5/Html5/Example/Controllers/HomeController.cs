﻿using System.Web.Mvc;
using Example.Models;

namespace Example.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        [HttpPost]
        public ActionResult Index(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return View(customer);
            }

            return View(customer);
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
