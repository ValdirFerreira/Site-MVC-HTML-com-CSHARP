﻿namespace System.Web.Mvc.Html5
{
    using Collections.Generic;
    using Globalization;
    using Text;

    /// <summary>
    /// The utilities.
    /// </summary>
    internal class Utilities
    {
        /// <summary>
        /// Used to merge a single attribute in HTML5 eg. autofocus
        /// </summary>
        /// <param name="isReadOnly">Is the element readonly</param>
        /// <param name="disabled">Is the element disabled</param>
        /// <param name="autoPlay">Shoudl autoplay</param>
        /// <param name="autoFocus">Should autofocus on element</param>
        /// <returns>A list of merged attributes.</returns>
        public IEnumerable<string> MergeSingleAttribute(bool isReadOnly, bool disabled, bool autoPlay, bool autoFocus)
        {
            List<string> singleAttributes = new List<string>();
            if (isReadOnly)
            {
                singleAttributes.Add("readonly");
            }

            if (disabled)
            {
                singleAttributes.Add("disabled");
            }

            if (autoPlay)
            {
                singleAttributes.Add("autoplay");
            }

            if (autoFocus)
            {
                singleAttributes.Add("autofocus");
            }

            return singleAttributes;
        }

        /// <summary>
        /// Uses the tagbuilder and gets the 
        /// attributes as a string
        /// </summary>
        /// <param name="tagBuilder">The Tagbuilder</param>
        /// <returns>The attributes.</returns>
        public string GetAttributesString(TagBuilder tagBuilder)
        {
            StringBuilder builder = new StringBuilder();

            // Loop through the original attributes
            foreach (KeyValuePair<string, string> pair in tagBuilder.Attributes)
            {
                string key = pair.Key;
                if (!string.Equals(key, "id", StringComparison.Ordinal) || !string.IsNullOrEmpty(pair.Value))
                {
                    string str2 = HttpUtility.HtmlAttributeEncode(pair.Value);
                    builder.AppendFormat(CultureInfo.InvariantCulture, " {0}=\"{1}\"", new object[] { key, str2 });
                }
            }

            return builder.ToString();
        }

        /// <summary>
        /// Uses the original Tagbuilder and adds the new HTML5
        /// single attributes to the string
        /// </summary>
        /// <param name="tagBuilder">The Tagbuilder</param>
        /// <param name="singleAttributes">The single HTML5 attributes</param>
        /// <returns>A single attribute.</returns>
        public string AddSingleAttributes(TagBuilder tagBuilder, IEnumerable<string> singleAttributes)
        {
            StringBuilder builder = new StringBuilder();

            // Loop through the original attributes
            foreach (KeyValuePair<string, string> pair in tagBuilder.Attributes)
            {
                string key = pair.Key;
                if (!string.Equals(key, "id", StringComparison.Ordinal) || !string.IsNullOrEmpty(pair.Value))
                {
                    string str2 = HttpUtility.HtmlAttributeEncode(pair.Value);
                    builder.AppendFormat(CultureInfo.InvariantCulture, " {0}=\"{1}\"", new object[] { key, str2 });
                }
            }

            // Add the singleAttributes
            foreach (string value in singleAttributes)
            {
                if (!string.IsNullOrEmpty(value))
                {
                    string encodedValue = HttpUtility.HtmlAttributeEncode(value);
                    builder.AppendFormat(CultureInfo.InvariantCulture, " {0}", encodedValue);
                }
            }

            return builder.ToString();
        }
    }
}
