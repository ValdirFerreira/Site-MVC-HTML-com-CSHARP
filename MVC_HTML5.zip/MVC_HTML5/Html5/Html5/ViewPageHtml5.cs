﻿namespace Html5
{
    using System.Web.Mvc;

    /// <summary>
    /// Represents the information that is required in order to render a strongly typed view as a Web Forms page.
    /// </summary>
    /// <typeparam name="TModel">The type of the model.</typeparam>
    public class ViewPageHtml5<TModel> : ViewPage
    {
        /// <summary>
        /// The View Data.
        /// </summary>
        private ViewDataDictionary<TModel> _viewData;

        /// <summary>
        /// Sets the view data dictionary for the associated view.
        /// </summary>
        /// <param name="viewData">A dictionary of data to pass to the view.</param>
        protected override void SetViewData(ViewDataDictionary viewData)
        {
            this._viewData = new ViewDataDictionary<TModel>(viewData);
            base.SetViewData(this._viewData);
        }

        /// <summary>
        /// Gets the Model property of the associated <see cref="T:System.Web.Mvc.ViewDataDictionary"/> object.
        /// </summary>
        /// <value></value>
        /// <returns>The Model property of the associated <see cref="T:System.Web.Mvc.ViewDataDictionary"/> object.</returns>
        public TModel Model
        {
            get
            {
                return (TModel) this.ViewData.Model;
            }
        }

        /// <summary>
        /// Gets or sets the HTML5 details.
        /// </summary>
        /// <value>The HTML5 details.</value>
        public static Html5Helper<TModel> Html5Details { get; set; }
    }
}
