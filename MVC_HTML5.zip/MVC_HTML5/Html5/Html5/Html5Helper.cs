﻿namespace Html5
{
    using System.Web.Mvc;
    using System.Web.Routing;

    /// <summary>
    /// Represents support for rendering HTML controls in a strongly typed view.
    /// </summary>
    /// <typeparam name="TModel">The type of the model.</typeparam>
    public class Html5Helper<TModel> : HtmlHelper
    {
        // Fields
        private ViewDataDictionary<TModel> _viewData;

        // Methods
        public Html5Helper(ViewContext viewContext, IViewDataContainer viewDataContainer)
            : this(viewContext, viewDataContainer, RouteTable.Routes)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Html5Helper&lt;TModel&gt;"/> class.
        /// </summary>
        /// <param name="viewContext">The view context.</param>
        /// <param name="viewDataContainer">The view data container.</param>
        /// <param name="routeCollection">The route collection.</param>
        /// <exception cref="T:System.ArgumentNullException">One or more parameters is null.</exception>
        public Html5Helper(ViewContext viewContext, IViewDataContainer viewDataContainer, RouteCollection routeCollection)
            : base(viewContext, viewDataContainer, routeCollection)
        {
            this._viewData = new ViewDataDictionary<TModel>(viewDataContainer.ViewData);
        }

        // Properties
        public ViewDataDictionary<TModel> ViewData
        {
            get
            {
                return this._viewData;
            }
        }
    }
}
