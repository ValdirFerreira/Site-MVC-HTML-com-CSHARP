﻿namespace System.Web.Mvc.Html5
{
    using Text;

    /// <summary>
    /// The audio and video class.
    /// </summary>
    public static class AudioVideo
    {
        /// <summary>
        /// Builds an Html5 audio element.
        /// </summary>
        /// <param name="helper">
        /// The helper.
        /// </param>
        /// <param name="source">
        /// The source.
        /// </param>
        /// <param name="controls">
        /// If set to <c>true</c> [controls].
        /// </param>
        /// <param name="autoplay">
        /// If set to <c>true</c> [autoplay].
        /// </param>
        /// <returns>
        /// An HTML5 audio tag.
        /// </returns>
        public static string Audio(this HtmlHelper helper, string source, bool controls, bool autoplay)
        {
            StringBuilder builder = BuildAudio(source);
            
            if (controls)
            {
                builder.Append("controls ");
            }

            if (autoplay)
            {
                builder.Append("autoplay ");
            }

            builder.Append(" />");

            return builder.ToString();
        }

        /// <summary>
        /// Builds an Html5 video element.
        /// </summary>
        /// <param name="helper">
        /// The helper.
        /// </param>
        /// <param name="source">
        /// The source.
        /// </param>
        /// <param name="controls">
        /// If set to <c>true</c> [controls].
        /// </param>
        /// <param name="autoplay">
        /// If set to <c>true</c> [autoplay].
        /// </param>
        /// <returns>
        /// An HTML5 video tag.
        /// </returns>
        public static string Video(this HtmlHelper helper, string source, bool controls, bool autoplay)
        {
            StringBuilder builder = BuildVideo(source);

            if (controls)
            {
                builder.Append("controls ");
            }

            if (autoplay)
            {
                builder.Append("autoplay ");
            }

            builder.Append(" />");

            return builder.ToString();
        }

        /// <summary>
        /// Builds the video HTML.
        /// </summary>
        /// <param name="source">The video source.</param>
        /// <returns>An HTML5 video tag.</returns>
        private static StringBuilder BuildVideo(string source)
        {
            StringBuilder builder = new StringBuilder("<video src='");
            builder.Append(source);
            builder.Append("' ");

            return builder;
        }

        /// <summary>
        /// Builds the audio HTML.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>An HTML5 audio tag.</returns>
        private static StringBuilder BuildAudio(string source)
        {
            StringBuilder builder = new StringBuilder("<audio src='");
            builder.Append(source);
            builder.Append("' ");

            return builder;
        }
    }
}
