﻿namespace System.Web.Mvc.Html5
{
    /// <summary>
    /// The extensions.
    /// </summary>
    internal static class Extensions
    {
        /// <summary>
        /// The to html string.
        /// </summary>
        /// <param name="builder">
        /// The builder.
        /// </param>
        /// <returns>
        /// The <see cref="MvcHtmlString"/>.
        /// </returns>
        internal static MvcHtmlString ToHtmlString(this TagBuilder builder)
        {
            return MvcHtmlString.Create(builder.ToString(TagRenderMode.SelfClosing));
        }

        /// <summary>
        /// The to html string.
        /// </summary>
        /// <param name="tag">
        /// The tag.
        /// </param>
        /// <returns>
        /// The <see cref="MvcHtmlString"/>.
        /// </returns>
        internal static MvcHtmlString ToHtmlString(string tag)
        {
            return MvcHtmlString.Create(tag);
        }
    }
}
