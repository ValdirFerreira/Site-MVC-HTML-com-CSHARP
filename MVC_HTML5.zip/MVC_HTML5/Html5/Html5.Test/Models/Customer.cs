﻿using System.ComponentModel.DataAnnotations;

namespace Html5.Test.Models
{
    public class Customer
    {
        [Required]
        public string CustomerName { get; set; }

        [DataType(DataType.EmailAddress)]
        public string CustomerEmail { get; set; }

        public int CustomerAge { get; set; }

        public System.DateTime CreatedDate { get; set; }

        public bool IsActive { get; set; }

    }
}
