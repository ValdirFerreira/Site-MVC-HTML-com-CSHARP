﻿namespace Html5.Test
{
    using System;
    using System.IO;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;

    using Html5.Test.Models;

    using Moq;

    /// <summary>
    /// The test helpers.
    /// </summary>
    public static class TestHelpers
    {
        /// <summary>
        /// Builds the view data container.
        /// </summary>
        /// <param name="viewPage">The view page.</param>
        /// <param name="viewContext">The view context.</param>
        /// <returns></returns>
        public static Mock<IViewDataContainer> BuildViewDataContainer(out ViewPage<Customer> viewPage, out ViewContext viewContext)
        {
            ViewDataDictionary<Customer> viewDataDictionary =
                new ViewDataDictionary<Customer>(
                    new Customer { CustomerEmail = "test@test.com", CustomerName = "test", CustomerAge = 33, CreatedDate = new DateTime(2011,11,11)});

            var controllerContext = new ControllerContext(
                new Mock<HttpContextBase>().Object, new RouteData(), new Mock<ControllerBase>().Object);
            var viewContextMock =
                new Mock<ViewContext>(
                    new object[]
                        {
                            controllerContext, new Mock<IView>().Object, viewDataDictionary, new TempDataDictionary(),
                            new Mock<TextWriter>().Object
                        });

            viewContextMock.Setup(v => v.View).Returns(new Mock<IView>().Object);
            viewContextMock.Setup(v => v.ViewData)
                       .Returns(viewDataDictionary)
                       .Callback(() => { throw new Exception("ViewData extracted"); });
            viewContextMock.Setup(v => v.TempData).Returns(new TempDataDictionary());
            viewContextMock.Setup(v => v.Writer).Returns(new Mock<TextWriter>().Object);
            viewContextMock.Setup(v => v.RouteData).Returns(new RouteData());
            viewContextMock.Setup(v => v.HttpContext).Returns(new Mock<HttpContextBase>().Object);
            viewContextMock.Setup(v => v.Controller).Returns(new Mock<ControllerBase>().Object);
            viewContextMock.Setup(v => v.FormContext).Returns(new FormContext());

            // Set the objects we are going to return
            viewPage = new ViewPage<Customer>();
            viewContext = viewContextMock.Object;

            Mock<IViewDataContainer> viewDataContainer = new Mock<IViewDataContainer>();
            viewDataContainer.Setup(v => v.ViewData).Returns(viewDataDictionary);

            return viewDataContainer;
        }
    }
}
