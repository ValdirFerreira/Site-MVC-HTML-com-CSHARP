﻿namespace Html5.Test
{
    using System.Web.Mvc.Html5;
    using NUnit.Framework;
    using NUnit.Framework.SyntaxHelpers;

    [TestFixture]
    public class InputTypesTest
    {
        [Test]
        public void Html5Range_ShouldReturnCorrectHtmlString()
        {
            // Arrange
            const int minVaue = 0;
            const int maxValue = 50;
            const int defaultValue = 0;

            // Act
            string html5RangeString = InputTypes.Html5Range(null, minVaue, maxValue, null, defaultValue, null).ToHtmlString();

            // Assert
            Assert.That(html5RangeString, Is.EqualTo("<input max=\"50\" min=\"0\" type=\"range\" value=\"0\" />"));
        }

        [Test]
        public void Html5Range_ShouldReturnCorrectHtmlString_WithReadOnly()
        {
            // Arrange
            const int minVaue = 0;
            const int maxValue = 50;
            const int defaultValue = 0;
            const bool isReadOnly = true;

            // Act
            string html5RangeString =
                InputTypes.Html5Range(null, minVaue, maxValue, null, defaultValue, null, isReadOnly).ToHtmlString();

            // Assert
            Assert.That(html5RangeString, Is.EqualTo("<input max=\"50\" min=\"0\" type=\"range\" value=\"0\" readonly />"));
        }

        [Test]
        public void Html5TextBox_ShouldReturnCorrectHtmlString()
        {
            // Act
            string html5TextBoxString = InputTypes.Html5TextBox(null, null, InputTypes.InputType.Color).ToHtmlString();

            // Assert
            Assert.That(html5TextBoxString, Is.EqualTo("<input type=\"Color\" />"));
        }

        [Test]
        public void Html5TextBox_ShouldReturnCorrectHtmlStringAndName()
        {
            // Act
            string html5TextBoxString = InputTypes.Html5TextBox(null, "txtColour", InputTypes.InputType.Color).ToHtmlString();

            // Assert
            Assert.That(html5TextBoxString, Is.EqualTo("<input name=\"txtColour\" type=\"Color\" />"));
        }

        [Test]
        public void Html5TextBox_ShouldReturnCorrectHtmlStringAndName_WithReadonlyAndDisabled()
        {
            // Act
            string html5TextBoxString =
                InputTypes.Html5TextBox(null, "txtColour", InputTypes.InputType.Color, null, null, true, true).
                    ToHtmlString();

            // Assert
            Assert.That(html5TextBoxString, Is.EqualTo("<input name=\"txtColour\" type=\"Color\" readonly disabled />"));
        }

        [Test]
        public void Html5TextBox_ShouldReturnCorrectHtmlStringWithPlaceHolder()
        {
            // Arrange
            const bool required = true;

            // Act
            string html5TextBoxString =
                InputTypes.Html5TextBox(null, null, InputTypes.InputType.Color, null, "Please enter a colour").
                    ToHtmlString();

            // Assert
            Assert.That(html5TextBoxString, Is.EqualTo("<input placeholder=\"Please enter a colour\" type=\"Color\" />"));
        }

        [Test]
        public void Html5TextBox_ShouldReturnCorrectHtmlStringWithPlaceHolderAndDisabled()
        {
            // Arrange
            const bool required = true;

            // Act
            string html5TextBoxString =
                InputTypes.Html5TextBox(null, null, InputTypes.InputType.Color, null, "Please enter a colour", true).
                    ToHtmlString();

            // Assert
            Assert.That(html5TextBoxString, Is.EqualTo("<input placeholder=\"Please enter a colour\" type=\"Color\" readonly />"));
        }

        [Test]
        public void Html5TextBox_ShouldReturnCorrectHtmlStringWithPlaceHolderAndName()
        {
            // Arrange
            const bool required = true;

            // Act
            string html5TextBoxString = InputTypes.Html5TextBox(null, "txtColour", InputTypes.InputType.Color, null,
                                                                "Please enter a colour").ToHtmlString();

            // Assert
            Assert.That(html5TextBoxString, Is.EqualTo("<input name=\"txtColour\" placeholder=\"Please enter a colour\" type=\"Color\" />"));
        }
    }
}
