﻿namespace Html5.Test
{
    using System.Web.Mvc.Html5;
    using System.Web.Mvc;

    using Moq;
    using NUnit.Framework;
    using NUnit.Framework.SyntaxHelpers;
    using Models;

    [TestFixture]
    public class InputTypesForTest
    {
        [Test]
        public void Html5TextBoxFor_ShouldReturnCorrectHtmlStringWithColor()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Color).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" type=\"color\" value=\"test\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_ShouldReturnCorrectHtmlStringWithColor_AndReadOnly()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed =
                viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Color, null, null, true)
                    .ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" type=\"color\" value=\"test\" readonly />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_ShouldReturnCorrectHtmlStringWithColorAndPlaceholder()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            const string placeHolder = "Please enter a customer name";

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Color, null, placeHolder).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" placeholder=\"Please enter a customer name\" type=\"color\" value=\"test\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_ShouldReturnCorrectHtmlStringWithColorAndPlaceholderAndClass()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            const string placeHolder = "Please enter a customer name";
            object htmlAttributes = new { @class = "CssClass" };

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Color, htmlAttributes, placeHolder).ToHtmlString();

            // Assert
            const string result = "<input class=\"CssClass\" data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" placeholder=\"Please enter a customer name\" type=\"color\" value=\"test\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_ShouldReturnCorrectHtmlStringWithColorAndPlaceholderAndClassAndAutoFocus()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            const string placeHolder = "Please enter a customer name";
            object htmlAttributes = new { @class = "CssClass" };

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed =
                viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Color, htmlAttributes,
                                              placeHolder, false, false, true).ToHtmlString();

            // Assert
            const string result = "<input class=\"CssClass\" data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" placeholder=\"Please enter a customer name\" type=\"color\" value=\"test\" autofocus />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_ShouldReturnCorrectHtmlStringWithColorWithoutPlaceHolderAndClass()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Color, null, null).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" type=\"color\" value=\"test\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_WithPassword_ShouldReturnEmptyWithoutValue()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerName, InputTypes.InputType.Password).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" type=\"password\" value=\"\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_WithNumber_ShouldReturnWithNumberInputType()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerAge, InputTypes.InputType.Number).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-number=\"The field CustomerAge must be a number.\" data-val-required=\"The CustomerAge field is required.\" id=\"CustomerAge\" name=\"CustomerAge\" type=\"number\" value=\"33\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_WithNumberAndMaxMin_ShouldReturnWithNumberInputTypeWithMaxMin()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerAge, InputTypes.InputType.Number, new { max = 12, min = 40 }).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-number=\"The field CustomerAge must be a number.\" data-val-required=\"The CustomerAge field is required.\" id=\"CustomerAge\" max=\"12\" min=\"40\" name=\"CustomerAge\" type=\"number\" value=\"33\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5TextBoxFor_WithNoInputType_ShouldReturnCorrectHtmlStringWithEmail()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5TextBoxFor(model => model.CustomerEmail).ToHtmlString();

            // Assert
            const string result = "<input id=\"CustomerEmail\" name=\"CustomerEmail\" type=\"email\" value=\"test@test.com\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }
    }
}
