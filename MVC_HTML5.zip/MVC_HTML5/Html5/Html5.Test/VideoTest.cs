﻿namespace Html5.Test
{
    using NUnit.Framework;
    using NUnit.Framework.SyntaxHelpers;
    using System.Web.Mvc.Html5;

    [TestFixture]
    public class VideoTest
    {
        [Test]
        public void Video_ShouldReturnCorrectHtmlStringWithControlsAndAutoplay()
        {
            // Arrange
            const string source = "test.mp4";

            // Act
            string videoHtml = AudioVideo.Video(null, source, true, true);

            // Assert
            Assert.That(videoHtml, Is.EqualTo("<video src='test.mp4' controls autoplay  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Video_ShouldReturnCorrectHtmlStringWithControls()
        {
            // Arrange
            const string source = "test.mp4";

            // Act
            string videoHtml = AudioVideo.Video(null, source, true, false);

            // Assert
            Assert.That(videoHtml, Is.EqualTo("<video src='test.mp4' controls  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Video_ShouldReturnCorrectHtmlStringWithAutoplay()
        {
            // Arrange
            const string source = "test.mp4";

            // Act
            string videoHtml = AudioVideo.Video(null, source, false, true);

            // Assert
            Assert.That(videoHtml, Is.EqualTo("<video src='test.mp4' autoplay  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Video_ShouldReturnCorrectHtmlString()
        {
            // Arrange
            const string source = "test.mp4";

            // Act
            string videoHtml = AudioVideo.Video(null, source, false, false);

            // Assert
            Assert.That(videoHtml, Is.EqualTo("<video src='test.mp4'  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Video_WithNullValues_ShouldReturnCorrectHtml()
        {
            // Arrange


            // Act
            string videoHtml = AudioVideo.Video(null, null, false, false);

            // Assert
            Assert.That(videoHtml, Is.EqualTo("<video src=''  />"),
                        "The html is not in the correct format.");
        }
    }
}
