﻿namespace Html5.Test
{
    using NUnit.Framework;
    using NUnit.Framework.SyntaxHelpers;
    using System.Web.Mvc.Html5;


    [TestFixture]
    public class AudioTest
    {
        [Test]
        public void Audio_ShouldReturnCorrectHtmlStringWithControlsAndAutoplay()
        {
            // Arrange
            

            // Act
            string audioHtml = AudioVideo.Audio(null, "test.mp4", true, true);

            // Assert
            Assert.That(audioHtml, Is.EqualTo("<audio src='test.mp4' controls autoplay  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Audio_ShouldReturnCorrectHtmlStringWithControls()
        {
            // Arrange


            // Act
            string audioHtml = AudioVideo.Audio(null, "test.mp4", true, false);

            // Assert
            Assert.That(audioHtml, Is.EqualTo("<audio src='test.mp4' controls  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Audio_ShouldReturnCorrectHtmlStringWithAutoplay()
        {
            // Arrange


            // Act
            string audioHtml = AudioVideo.Audio(null, "test.mp4", false, true);

            // Assert
            Assert.That(audioHtml, Is.EqualTo("<audio src='test.mp4' autoplay  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Audio_ShouldReturnCorrectHtmlString()
        {
            // Arrange


            // Act
            string audioHtml = AudioVideo.Audio(null, "test.mp4", false, false);

            // Assert
            Assert.That(audioHtml, Is.EqualTo("<audio src='test.mp4'  />"),
                        "The html is not in the correct format.");
        }

        [Test]
        public void Audio_WithNullValues_ShouldReturnCorrectHtml()
        {
            // Arrange


            // Act
            string audioHtml = AudioVideo.Audio(null, null, false, false);

            // Assert
            Assert.That(audioHtml, Is.EqualTo("<audio src=''  />"),
                        "The html is not in the correct format.");
        }
    }
}
