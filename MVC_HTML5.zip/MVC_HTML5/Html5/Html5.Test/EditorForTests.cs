﻿namespace Html5.Test
{
    using System.Web.Mvc;
    using System.Web.Mvc.Html5;

    using Html5.Test.Models;

    using Moq;

    using NUnit.Framework;
    using NUnit.Framework.SyntaxHelpers;

    [TestFixture]
    public class EditorForTests
    {
        [Test]
        public void Html5EditorFor_WithoutInputType_ShouldReturnCorrectHtmlStringWithEmail()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5EditorFor(model => model.CustomerEmail).ToHtmlString();

            // Assert
            const string result = "<input id=\"CustomerEmail\" name=\"CustomerEmail\" type=\"email\" value=\"test@test.com\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5EditorFor_WithoutInputType_ShouldReturnCorrectHtmlStringWithRequiredDataValidation()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5EditorFor(model => model.CustomerName).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-required=\"The CustomerName field is required.\" id=\"CustomerName\" name=\"CustomerName\" type=\"text\" value=\"test\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }

        [Test]
        public void Html5EditorFor_WithInputType_ShouldReturnCorrectHtmlStringWithRequiredDataValidation()
        {
            // Arrange
            ViewPage<Customer> viewPage;
            ViewContext viewContext;
            Mock<IViewDataContainer> viewDataContainer = TestHelpers.BuildViewDataContainer(out viewPage, out viewContext);

            viewPage.Html = new HtmlHelper<Customer>(viewContext, viewDataContainer.Object);

            // Act
            string computed = viewPage.Html.Html5EditorFor(model => model.CreatedDate, InputTypes.InputType.Datetime).ToHtmlString();

            // Assert
            const string result = "<input data-val=\"true\" data-val-date=\"The field CreatedDate must be a date.\" data-val-required=\"The CreatedDate field is required.\" id=\"CreatedDate\" name=\"CreatedDate\" type=\"datetime\" value=\"11/11/2011 00:00:00\" />";
            Assert.That(computed, Is.EqualTo(result), "The Html returned is incorrect.");
        }
    }
}
